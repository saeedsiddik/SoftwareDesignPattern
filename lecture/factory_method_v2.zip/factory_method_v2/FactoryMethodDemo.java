package factory_method;

public class FactoryMethodDemo {
public static void main(String[] args) {

    NotificationRequest[] requests = {
        new NotificationRequest(
            new EmailService(),
            "ana@shop.com",
            "Order shipped"
        ),

        new NotificationRequest(
            new SmsService(),
            "555-0101",
            "Your order has shipped"
        ),

        new NotificationRequest(
            new PushService(),
            "device-42",
            "Order shipped"
        )
    };

    for (NotificationRequest request : requests) {
        request.service.notifyUser(request.to, request.message);
    }
}
}

package factory_method;

class NotificationRequest {
    NotificationService service;
    String to;
    String message;

    NotificationRequest(NotificationService service,
                        String to,
                        String message) {
        this.service = service;
        this.to = to;
        this.message = message;
    }
}